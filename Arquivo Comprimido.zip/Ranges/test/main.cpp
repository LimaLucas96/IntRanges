#include <iterator> // begin(), end()

#include "gtest/gtest.h"
#include "../include/int_ranges.h"

using namespace ir;

TEST(IntRange, NegateBasic)
{
    ir::value_type A[]{ 1, 2, 3, 4, 5 };
    ir::value_type A_E[]{ -1, -2, -3, -4, -5 };

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::negate( std::begin(A), std::end(A) );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E) ) );
}

TEST(IntRange, NegateZeros)
{
    ir::value_type A[]{ 0, 0, 0, 0, 0 };
    ir::value_type A_E[]{ 0, 0, 0, 0, 0 };

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::negate( std::begin(A), std::end(A) );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E) ) );
}
TEST(IntRange, NegateMixed)
{
    ir::value_type A[]{ 0, -2, 1, -3, 0 };
    ir::value_type A_E[]{ 0, 2, -1, 3, 0 };

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::negate( std::begin(A), std::end(A) );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E) ) );
}

TEST(IntRange,MinBasic){

    ir::value_type A[]={1,2,-3,-4,5,-6};
    auto len = std::begin(A)+5;

    auto result = ir::min(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
  //  ASSERT_TRUE(std::equal(*result,-6));
}

TEST(IntRange,MinBasic2){

    ir::value_type A[]={1,2,-3,-4,5,-6};
    auto len = std::begin(A)+3;

    auto result = ir::min(std::begin(A)+1,std::begin(A)+5);
    ASSERT_EQ(result,len);
  //  ASSERT_TRUE(std::equal(*result,-6));
}

TEST(IntRange,MinZeros){

    ir::value_type A[]={0,0,0,0,0,0};
    auto len = std::begin(A);

    auto result = ir::min(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
  //  ASSERT_TRUE(std::equal(*result,-6));
}

TEST(IntRange,MinNegative){

    ir::value_type A[]={-1,-2,-3,-4,-5,-6};
    auto len = std::begin(A)+5;

    auto result = ir::min(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
  //  ASSERT_TRUE(std::equal(*result,-6));
}

TEST(IntRange,MinPositive){

    ir::value_type A[]={1,2,3,4,5,6};
    auto len = std::begin(A);

    auto result = ir::min(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
  //  ASSERT_TRUE(std::equal(*result,-6));
}

TEST(IntRange, ReverseBasic)
{
    ir::value_type A[]{ 1, 2, 3, 4, 5};
    ir::value_type A_E[]{ 5, 4, 3, 2, 1};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::reverse( std::begin(A), std::end(A) );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E) ) );
}

TEST(IntRange, ReverseBasic2)
{
    ir::value_type A[]{ 1, 2, 3, 4, 5};
    ir::value_type A_E[]{ 5, 2, 3, 4, 1};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::reverse( std::begin(A), std::end(A) );
    ir::reverse( std::begin(A)+1, std::begin(A)+4);
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::begin(A), std::begin(A_E) ) );
}

TEST(IntRange, ReverseNegative)
{
    ir::value_type A[]{ -1, -2, -3, -4, -5};
    ir::value_type A_E[]{ -5, -4, -3, -2, -1};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::reverse( std::begin(A), std::end(A) );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::begin(A), std::begin(A_E) ) );
}

TEST(IntRange, ReverseNegative2)
{
    ir::value_type A[]{ -1, -2, -3, -4, -5};
    ir::value_type A_E[]{ -5, -3, -4, -2, -1};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::reverse( std::begin(A), std::end(A) );
    ir::reverse( std::begin(A)+1, std::begin(A)+3);
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::begin(A), std::begin(A_E) ) );
}

TEST(IntRange, ScalarMultiplicationBasic)
{
    ir::value_type A[]={1,2,-3,-4,5,-6};
    ir::value_type A_E[]{ 3, 6 , -9 ,-12, 15, -18};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::scalar_multiplication( std::begin(A), std::end(A), 3 );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::begin(A), std::begin(A_E) ) );
}

TEST(IntRange, ScalarMultiplicationNegative)
{
    ir::value_type A[]={-1,-2,-3,-4,-5,-6};
    ir::value_type A_E[]{ -5, -10 , -15 ,-20, -25, -30};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::scalar_multiplication( std::begin(A), std::end(A), 5 );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::begin(A), std::begin(A_E) ) );
}

TEST(IntRange, ScalarMultiplicationZero)
{
    ir::value_type A[]={0,0,0,0};
    ir::value_type A_E[]{ 0,0,0,0};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::scalar_multiplication( std::begin(A), std::end(A), 3 );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::begin(A), std::begin(A_E) ) );
}

TEST(IntRange, ScalarMultiplicationPositive)
{
    ir::value_type A[]={1,2,3,4,5,6};
    ir::value_type A_E[]{ 3, 6 , 9 ,12, 15, 18};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::scalar_multiplication( std::begin(A), std::end(A), 3 );
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::begin(A), std::begin(A_E) ) );
}

TEST(IntRange, Dot_productBasic)
{
    ir::value_type A[]={1 , 3 , -5 , 4 , -2 , -1 };
    ir::value_type A_E= 3;
    
    auto result=ir::dot_product( std::begin(A), std::begin(A)+3, std::begin(A)+3);
    
    ASSERT_TRUE( result == A_E);
}

TEST(IntRange, Dot_productNegative)
{
    ir::value_type A[]={-1 , -3 , -5 , -4 , -2 , -1 };
    ir::value_type A_E= 15;
    
    auto result=ir::dot_product( std::begin(A), std::begin(A)+3, std::begin(A)+3);
    
    ASSERT_TRUE( result == A_E);
}

TEST(IntRange, Dot_productZero)
{
    ir::value_type A[]={0 , 0 , 0 , 0 , 0 , 0};
    ir::value_type A_E= 0;
    
    auto result=ir::dot_product( std::begin(A), std::begin(A)+3, std::begin(A)+3);
    
    ASSERT_TRUE( result == A_E);
}

TEST(IntRange,CompactBasic){

    ir::value_type A[]={-2,-8,2,7,-3,10,1,0,-3,7};
    auto len = std::begin(A)+5;

    auto result = ir::compact(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
}


TEST(IntRange,CompactNegative){

    ir::value_type A[]={-2,-8,-2,-7,-3,-10,-1,-5,-3,-7};
    auto len = std::begin(A);

    auto result = ir::compact(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
}

TEST(IntRange,CompactPositive){

    ir::value_type A[]={2,8,2,7,3,10,1,5,3,7};
    auto len = std::end(A);

    auto result = ir::compact(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
}

TEST(IntRange,CompactZeros){

    ir::value_type A[]={0,0,0,0,0};
    auto len = std::begin(A);

    auto result = ir::compact(std::begin(A),std::end(A));
    ASSERT_EQ(result,len);
}

TEST(IntRange, CopyBasic)
{
    ir::value_type A[]={1,2,3,4,5};
    ir::value_type B[]={0,0,0};
    ir::value_type A_E[]{ 2,3,4};

    auto len_before{ std::distance( std::begin(B), std::end(B) ) };
    auto result=ir::copy( std::begin(A)+1, std::begin(A)+4, std::begin(B));
    auto len_after{ std::distance( std::begin(B), result ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(B), result, std::begin(A_E) ) );
}

TEST(IntRange, CopyBasicAll)
{
    ir::value_type A[]={1,2,3,4,5};
    ir::value_type B[]={0,0,0,0,0};
    ir::value_type A_E[]{ 1,2,3,4,5};

    auto len_before{ std::distance( std::begin(B), std::end(B) ) };
    auto result=ir::copy( std::begin(A), std::end(A), std::begin(B));
    auto len_after{ std::distance( std::begin(B), result ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(B), result, std::begin(A_E) ) );
}

TEST(IntRange, CopyNegative)
{
    ir::value_type A[]={-1,-2,-3,-4,-5};
    ir::value_type B[]={0,0,0,0,0};
    ir::value_type A_E[]{ -1,-2,-3,-4,-5};

    auto len_before{ std::distance( std::begin(B), std::end(B) ) };
    auto result=ir::copy( std::begin(A), std::end(A), std::begin(B));
    auto len_after{ std::distance( std::begin(B), result ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(B), result, std::begin(A_E) ) );
}

TEST(IntRange, UniqueBasic)
{
    ir::value_type A[]={ 1 , 2 , 1 , 2 , 3 , 3 , 1 , 2 , 4 , 5 , 3 , 4 , 5 };
    ir::value_type A_E[]{ 1,2,3,4,5};
    auto A_E_PONTEIRO=std::begin(A)+5;

    auto result = ir::unique( std::begin(A), std::end(A));
    ASSERT_EQ( A_E_PONTEIRO, result );
    ASSERT_TRUE( std::equal( std::begin(A), result, std::begin(A_E)) );
}

TEST(IntRange, UniqueNegative)
{
    ir::value_type A[]={ -4,-4,-4,-3,-2,-3,-1,-1 };
    ir::value_type A_E[]={ -4,-3,-2,-1};
    auto A_E_PONTEIRO=std::begin(A)+4;

    auto result = ir::unique( std::begin(A), std::end(A));
    ASSERT_EQ( A_E_PONTEIRO, result );
    ASSERT_TRUE( std::equal( std::begin(A), result, std::begin(A_E)) );
}

TEST(IntRange, UniqueMixed)
{
    ir::value_type A[]={ -4,-4,-4,-3,-2,-3,-1,-1,0,0,3,3 };
    ir::value_type A_E[]{ -4,-3,-2,-1,0,3};
    auto A_E_PONTEIRO=std::begin(A)+6;

    auto result = ir::unique( std::begin(A), std::end(A));
    ASSERT_EQ( A_E_PONTEIRO, result );
    ASSERT_TRUE( std::equal( std::begin(A), result, std::begin(A_E)) );
}

TEST(IntRange, Sort_MarblesBasic)
{
    enum ball_t{B=0,W=1};

    ir::value_type A[]={ W , B , B , W , W , B , W };
    ir::value_type A_sorted[]= { B , B , B , W , W , W , W };
    auto A_E_PONTEIRO=std::begin(A)+3;

    auto result = ir::sort_marbles( std::begin(A), std::end(A));
    ASSERT_EQ( A_E_PONTEIRO, result );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_sorted)) );
}

TEST(IntRange, Sort_MarblesAllBlack)
{
    enum ball_t{B=0,W=1};

    ir::value_type A[]={ B , B , B , B , B , B , B };
    ir::value_type A_sorted[]= { B , B , B , B , B , B , B };
    auto A_E_PONTEIRO=std::end(A);

    auto result = ir::sort_marbles( std::begin(A), std::end(A));
    ASSERT_EQ( A_E_PONTEIRO, result );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_sorted)) );
}

TEST(IntRange, Sort_MarblesAllWhite)
{
    enum ball_t{B=0,W=1};

    ir::value_type A[]={ W , W , W , W , W , W , W };
    ir::value_type A_sorted[]= { W , W , W , W , W , W , W };
    auto A_E_PONTEIRO=std::begin(A);

    auto result = ir::sort_marbles( std::begin(A), std::end(A));
    ASSERT_EQ( A_E_PONTEIRO, result );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_sorted)) );
}

TEST(IntRange, PartitionBasic)
{
    ir::value_type A[]={-5,7,10,7,8,9,1,7,-2,3};
    ir::value_type A_E[]{ -5,1,-2,3,7,7,7,9,10,8};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::partition( std::begin(A), std::end(A), std::begin(A)+3);
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E)) );
}

TEST(IntRange, PartitionBasic2)
{
    ir::value_type A[]={-5, 7, 10, 7, 8, 9, 1, 7, -2, 3};
    ir::value_type A_E[]{ -5, 7, 7, 8, 9, 1, 7, -2, 3, 10};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::partition( std::begin(A), std::end(A), std::begin(A)+2);
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E)) );
}

TEST(IntRange, RotateBasic)
{
    ir::value_type A[]={ 1, 2, 3, 4, 5, 6, 7 };
    ir::value_type A_E[]{ 3,4,5,6,7,1,2};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::rotate( std::begin(A), std::begin(A)+2, std::end(A));
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E)) );
}

TEST(IntRange, RotateBasic2)
{
    ir::value_type A[]={ 1, 2, 3, 4, 5, 6, 7 };
    ir::value_type A_E[]{ 6,7,1,2,3,4,5};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::rotate( std::begin(A), std::begin(A)+5, std::end(A));
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E)) );
}

TEST(IntRange, RotateZeros)
{
    ir::value_type A[]={ 0,0,0,0,0 };
    ir::value_type A_E[]{ 0,0,0,0,0};

    auto len_before{ std::distance( std::begin(A), std::end(A) ) };
    ir::rotate( std::begin(A), std::begin(A)+2, std::end(A));
    auto len_after{ std::distance( std::begin(A), std::end(A) ) };
    ASSERT_EQ( len_before, len_after );
    ASSERT_TRUE( std::equal( std::begin(A), std::end(A), std::begin(A_E)) );
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
