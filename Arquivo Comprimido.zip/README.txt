Linguagem de Programação I • DIM0120
-Exercicio sobre ranges de interios-

Projeto produzido por Lucas Lima Marques de Oliveira.

O projeto foi dividido em duas pastas, a pasta Ranges foi utilisada para fazer os testes com Gtest e criar o makefile e o lib com o Cmake. Ja pasta App consite em um programa que usa o lib, criado pelo Cmake, para executar as funcoes criadas no exercicio.

Para compilar o Programa de executar as funcoes:
------------------------------------------------
	$ cd App
	$ make

Para Executar o programa de executar funcoes:
---------------------------------------------
	$ ./App/App_ranges

Para Executar os Testes das funcoes:
------------------------------------
	$ ./Ranges/build/run_tests


O codigo com do programa de testes se encontra na pasta test dentro da pasta Ranges.


